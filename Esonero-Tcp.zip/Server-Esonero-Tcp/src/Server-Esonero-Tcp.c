/*
 ============================================================================
 Name        : Server-Esonero-Tcp.c
 Author      : Marco Angelo Lillo
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "NetMessage.h"

#include <stdio.h>
#include <stdlib.h>

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#define PROTOPORT 60000
#define QLEN 5

// mathematical operations
void calculate(data *msg); // determines which operation to execute
void add(data*);
void mult(data*);
void sub(data*);
void division(data*);

void errorHandler(char *errorMessage) {
	printf("%s\n", errorMessage);
}

void clearWinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

void initializeWSDATA(WSADATA *wsa_data) {
	int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
	if (result != 0) {
		errorHandler("error with WSDATA initialization\n");
	}

}

int main(int argc, char *argv[]) {
	printf("welcome to the server\n\n");

	// set the port number if passed by argument
	int port;
	if (argc > 1) {
		port = atoi(argv[1]);	// convert port number in binary format
	} else
		port = PROTOPORT;

	if (port < 0) {
		printf("invalid number port: %s\n", argv[1]);
		return 0;
	}

	// initialize WSDATA
#if defined WIN32
	WSADATA wsa_data;
	initializeWSDATA(&wsa_data);
#endif

	// initialize socket
	int my_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (my_socket < 0) {
		errorHandler("socket creation failed\n");
		clearWinsock();
		return -1;
	}

	// assign address and port to the socket
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad));

	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = inet_addr("127.0.0.1");	// server address
	sad.sin_port = htons(port);	// server port for the process

	if (bind(my_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		errorHandler("socket bind failed\n");
		closesocket(my_socket);
		clearWinsock();
		system("pause");
		return -1;
	}

	// set server for listening
	if (listen(my_socket, QLEN) < 0) {
		errorHandler("listen failed\n");
		closesocket(my_socket);
		clearWinsock();
		system("pause");
		return -1;
	} else
		printf("server is waiting for a client request\n");

	// accept a new connection
	struct sockaddr_in cad;	// client struct
	int client_socket;	// socket descriptor for client
	int client_len;	// length of client address

	while (1) {
		client_len = sizeof(cad);
		if ((client_socket = accept(my_socket, (struct sockaddr*) &cad,
				&client_len)) < 0) {
			errorHandler("accepting failed\n");
			closesocket(client_socket);
			clearWinsock();
			system("pause");
			return 0;
		}
		printf("Connection established with %s:%d\n", inet_ntoa(cad.sin_addr),ntohs(cad.sin_port));

		int end = 0;
		while (end == 0) {
			int bytes_rcvd = 0;
			int total_bytes_rcvd = 0;
			data buf;
			while (total_bytes_rcvd < sizeof(data)) {
				if ((bytes_rcvd = recv(client_socket, &buf, sizeof(data), 0))
						<= 0) {
					errorHandler("received failed or connection closed\n");
					closesocket(client_socket);
					end = 1;
					break;
				}
				total_bytes_rcvd += bytes_rcvd;
			}

			if (end == 0) {
				printf("\nreceived data from client:\n");
				printf("\noperator: %c", buf.operator);
				printf("\nfirst operand: %d", buf.firstOperand);
				printf("\nsecond operand: %d\n", buf.secondOperand);

				calculate(&buf); // calculate the operation
				if (send(client_socket, &buf, sizeof(data), 0)
						!= sizeof(data)) {
					errorHandler("error occured during sending data\n");
					closesocket(client_socket);
					clearWinsock();
					system("pause");
					return -1;
				}
				printf("\n\n");
			}

		}

	}
	system("pause");
	return 0;
}
/* function that decides the operation*/
void calculate(data *msg) {
	if (msg->operator == '+')
		add(msg);
	else if (msg->operator == '-')
		sub(msg);
	else if (msg->operator == '*')
		mult(msg);
	else
		division(msg);
	if(msg->error==1)
		printf("\n%s\n",msg->errorMsg);
	else
		printf("\nresult: %d", msg->result);

}
/* function that sums the first operand to the second operand */
void add(data *msg) {
	msg->result = msg->firstOperand + msg->secondOperand;
}
/* function that multiplies the first operand to the second operand */
void mult(data *msg) {
	msg->result = msg->firstOperand * msg->secondOperand;
}
/* function that subtracts the second operand to the first operand */
void sub(data *msg) {
	msg->result = msg->firstOperand - msg->secondOperand;
}
/* function that divides the first operand by the second operand */
void division(data *msg) {
	if (msg->secondOperand == 0) {
		msg->result = 0;
		strcpy(msg->errorMsg, "Cannot divide by 0");
		msg->error = 1;
	} else
		msg->result = msg->firstOperand / msg->secondOperand;
}
