/*
 * NetMessage.h
 *
 *  Created on: 21 nov 2021
 *      Authors: Francesco, Marco
 */

#ifndef NETMESSAGE_H_
#define NETMESSAGE_H_

typedef struct data{
    char operator;
    int firstOperand;
    int secondOperand;
    int result;
    int error; // error flag
    char errorMsg[20]; // error message for the division by 0
}data;


#endif /* NETMESSAGE_H_ */
