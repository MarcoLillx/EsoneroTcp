/*
 ============================================================================
 Name        : Client-Esonero-Tcp.c
 Authors      : Francesco Ferrulli
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "NetMessage.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#define PROTOPORT 60000

int readData(data *msg);

void errorHandler(char *errorMessage) {
	printf("%s\n", errorMessage);
}

void clearWinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

void printHelp() {

	printf("\nsyntax of the calculator:\n");
	printf("		[operator] [number] [number]\n");
	printf("		- operator must be one of these: + , - , * , / , = \n");
	printf("		- number : integer number\n");
	printf("			'=' is used to close the connection with the server");

}

void initializeWSDATA(WSADATA *wsa_data) {
	int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
	if (result != 0) {
		errorHandler("error with WSDATA initialization\n");
	}
}

int main(int argc, char *argv[]) {

	// set address and port number if passed by argument
	char serverIp[20];
	int port;
	if (argc > 1) {
		strcpy(serverIp, argv[1]);
		port = atoi(argv[2]);
	} else {
		strcpy(serverIp, "127.0.0.1");
		port = PROTOPORT;
	}

	// initialize WSDATA
#if defined WIN32
	WSADATA wsa_data;
	initializeWSDATA(&wsa_data);
#endif

	// socket creation
	int c_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (c_socket < 0) {
		errorHandler("socket creation failed\n");
		closesocket(c_socket);
		clearWinsock();
		return -1;
	}

	// struct for server
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad));

	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = inet_addr(serverIp);	// server ip
	sad.sin_port = htons(port);	// convert host to network format

	// connection to server
	if (connect(c_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		errorHandler("connection failed\n");
		closesocket(c_socket);
		clearWinsock();
		system("pause");
		return -1;
	}

	fflush(stdout);
	// begin client-server comunication
	data msg;

	printHelp();
	while (1) {
		int choice = readData(&msg);
		if (choice == -1) {
			closesocket(c_socket);
			clearWinsock();
			printf("\n\n");
			system("pause");
			return 0;
		} else {

			// sending data to server
			if (send(c_socket, &msg, sizeof(data), 0) != sizeof(data)) {
				errorHandler(
						"send() sent a different number of bytes than expected\n");
				closesocket(c_socket);
				clearWinsock();
				system("pause");
				return -1;
			}

			// receiving data from server
			data receivedMsg;
			int total_bytes_rcvd = 0;
			int bytes_rcvd;
			while (total_bytes_rcvd < sizeof(data)) {
				if ((bytes_rcvd = recv(c_socket, &receivedMsg, sizeof(data), 0))
						<= 0) {
					errorHandler("\nfailed or connection close..\n");
					closesocket(c_socket);
					clearWinsock();
					system("pause");
					return -1;
				}
				total_bytes_rcvd += bytes_rcvd; // Keep tally of total bytes
			}

			if (receivedMsg.error == 1)
				printf("\n\n%s", receivedMsg.errorMsg); // print error message relative to division by 0
			else
				printf("\n\nresult: %d", receivedMsg.result);
		}

	}

	system("pause");
	return 0;
}

int readData(data *msg) {

	printf("\ninsert the operation to calculate: ");
	char ch;
	msg->error = 0;
	while (ch != 13) {
		ch = getch();
		while ((ch != '=') & (ch != '+') & (ch != '-') & (ch != '*')
				& (ch != '/'))
			ch = getch();

		if (ch == '=')
			return -1;
		if ((ch == '+') | (ch == '-') | (ch == '/') | (ch == '*')) {
			printf("%c", ch);
			msg->operator = ch;
		}

		// insert whitespace
		ch = getch();
		while (ch != 32)
			ch = getch();
		printf("%c", ch);

		char number[20] = "";
		int n = 0;

		// insert at least one number of first operand
		ch = getch();
		while ((ch < '0') | (ch > '9'))
			ch = getch();
		printf("%c", ch);

		n = ch - 48;
		strncat(number, &ch, 1);

		// insert the rest of numbers
		while (ch != 32) {
			ch = getch();

			if ((ch >= '0') & (ch <= '9')) {
				printf("%c", ch);
				strncat(number, &ch, 1);
				n = n * 10 + (ch - 48);
			}

			if (ch == 32) {
				printf("%c", ch);
				//msg->firstOperand = atoi(number);
				msg->firstOperand = n;
			}
		}

		n = 0;
		strcpy(number, "");

		// insert at least one number of second operand
		ch = getch();
		while ((ch < '0') | (ch > '9'))
			ch = getch();
		printf("%c", ch);
		n = ch - 48;

		strncat(number, &ch, 1);

		// insert the rest of numbers
		while (ch != 13) {
			ch = getch();

			if ((ch >= '0') & (ch <= '9')) {
				printf("%c", ch);
				n = n * 10 + (ch - 48);
				strncat(number, &ch, 1);
			}

			if (ch == 13) {
				printf("%c", ch);
				msg->secondOperand = n;
			}
		}

	}
	return 0;
}
